package kr.ac.hs.farm;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class LandmarkManager {
    private final List<Landmark> landmarks = new ArrayList<>();
    private final Context context;

    public LandmarkManager(Context context) {
        this.context = context;
        loadLandmarks(); // 외부 파일에서 읽기
    }

    public List<Landmark> getLandmarks() {
        return landmarks;
    }

    private void loadLandmarks() {
        try (InputStream is = context.getResources().openRawResource(R.raw.landmarks);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split("\\|");
                if (parts.length < 3) continue;

                String name = parts[0].trim();
                double lat = Double.parseDouble(parts[1].trim());
                double lng = Double.parseDouble(parts[2].trim());

                landmarks.add(new Landmark(name, lat, lng));
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
