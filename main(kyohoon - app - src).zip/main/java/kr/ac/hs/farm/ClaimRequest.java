package kr.ac.hs.farm;

public class ClaimRequest {
    private String id;
    private String type;

    public ClaimRequest(String id, String type) {
        this.id = id;
        this.type = type;
    }

}